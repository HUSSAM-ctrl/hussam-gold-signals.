import React, { useEffect, useState } from 'react';

export default function App(){
  const [signals, setSignals] = useState([]);
  const [status, setStatus] = useState('غير متصل');

  useEffect(()=>{
    const ws = new WebSocket('wss://' + (location.hostname || 'localhost') + ':8000/ws'.replace('https://','').replace('http://',''));
    ws.onopen = ()=> setStatus('متصل');
    ws.onclose = ()=> setStatus('مغلق');
    ws.onerror = ()=> setStatus('خطأ في الاتصال');

    ws.onmessage = (ev)=>{
      try{
        const msg = JSON.parse(ev.data);
        if(msg.type === 'signal'){
          setSignals(prev => [msg.payload, ...prev].slice(0,50));
        }
      }catch(e){ console.error(e); }
    }

    return ()=> ws.close();
  },[]);

  return (
    <div style={{fontFamily:'sans-serif',background:'#0f1720',minHeight:'100vh',color:'#fff',padding:20}}>
      <div style={{maxWidth:900,margin:'0 auto'}}>
        <h1 style={{fontSize:24,fontWeight:700,marginBottom:12}}>توصيات سريعة — ذهب (XAUUSD)</h1>
        <div style={{marginBottom:12}}>حالة الإتصال: <span style={{fontWeight:700}}>{status}</span></div>

        <div style={{display:'flex',gap:12,flexWrap:'wrap'}}>
          <div style={{flex:1,background:'#111827',padding:12,borderRadius:8}}>
            <h2 style={{fontWeight:600,marginBottom:8}}>آخر التوصيات</h2>
            {signals.length===0 && <div style={{color:'#9CA3AF'}}>لا توجد توصيات بعد</div>}
            <ul style={{listStyle:'none',padding:0,margin:0}}>
              {signals.map((s, i)=> (
                <li key={i} style={{padding:8,borderBottom:'1px solid #111',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                  <div>
                    <div style={{fontWeight:700}}>{s.action} — {s.instrument}</div>
                    <div style={{fontSize:12,color:'#9CA3AF'}}>{new Date(s.time).toLocaleString()}</div>
                  </div>
                  <div style={{textAlign:'right',fontSize:13}}>
                    <div>Entry: {s.entry}</div>
                    <div>SL: {s.sl}</div>
                    <div>TP: {s.tp}</div>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div style={{width:320,background:'#111827',padding:12,borderRadius:8}}>
            <h2 style={{fontWeight:600,marginBottom:8}}>سجل التيك (Tick Feed)</h2>
            <div style={{fontSize:12,color:'#9CA3AF'}}>يظهر هنا التيك والداتا الحية عند اتصال MT5</div>
          </div>
        </div>

        <div style={{marginTop:12,fontSize:12,color:'#94A3B8'}}>ملاحظة: هذه توصيات عرضية فقط. اختبر قبل التداول الحقيقي.</div>
      </div>
    </div>
  )
}