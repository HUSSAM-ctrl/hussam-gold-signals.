from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
import asyncio
import uvicorn
import json

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

clients = set()

@app.websocket('/ws')
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    clients.add(ws)
    try:
        while True:
            await ws.receive_text()  # placeholder to keep connection alive / receive pings
    except WebSocketDisconnect:
        pass
    finally:
        if ws in clients:
            clients.remove(ws)

async def broadcast(msg: dict):
    dead = []
    for ws in list(clients):
        try:
            await ws.send_text(json.dumps(msg))
        except Exception:
            dead.append(ws)
    for d in dead:
        if d in clients:
            clients.remove(d)

@app.post('/push_signal')
async def push_signal(payload: dict):
    # payload example: {"type":"signal","payload": {...}}
    await broadcast(payload)
    return {"ok": True}

if __name__=='__main__':
    uvicorn.run('server:app', host='0.0.0.0', port=8000)